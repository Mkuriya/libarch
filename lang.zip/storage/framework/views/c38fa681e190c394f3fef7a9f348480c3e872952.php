<?php echo $__env->make('partials.adminnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- component -->
<div class="p-10">
  <dl class="mt-5 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3 place-items-center">
    <div class="relative overflow-hidden rounded-lg bg-gray-600 px-4 pb-12 pt-5 shadow sm:px-6 sm:pt-6 text-center flex flex-col items-center justify-center">
      <p class="text-2xl font-medium text-white">Total Uploaded</p>
      <p class="text-2xl font-semibold text-gray-100"><?php echo e($totalUpload); ?></p><br>
      <a href="/admin/dashboard/archive" class="block">
        <div class="absolute inset-x-0 bottom-0 bg-whitebg hover:bg-gray-700 px-4 py-4 sm:px-6">
          <div class="text-sm text-center">
            <p class="font-medium text-white">View all</p>
          </div>
        </div>
      </a>
    </div>

    <div class="relative overflow-hidden rounded-lg bg-gray-600 px-4 pb-12 pt-5 shadow sm:px-6 sm:pt-6 text-center flex flex-col items-center justify-center">
      <p class="text-2xl font-medium text-white">Total Pending</p>
      <p class="text-2xl font-semibold text-gray-100"><?php echo e($totalPending); ?></p>
      <br>
      <a href="/admin/dashboard/archive/pending" class="block ">  
        <div class="absolute inset-x-0 bottom-0 bg-whitebg hover:bg-gray-700 px-4 py-4 sm:px-6">
          <div class="text-sm text-center">
            <p class="font-medium text-white">View all</p>
          </div>
        </div>
      </a>
    </div>

    <div class="relative overflow-hidden rounded-lg bg-gray-600 px-4 pb-12 pt-5 shadow sm:px-6 sm:pt-6 text-center flex flex-col items-center justify-center">
      <p class="text-2xl font-medium text-white">Total Student</p>
      <p class="text-2xl font-semibold text-gray-100"><?php echo e($totalStudent); ?></p><br>
      <a href="/admin/dashboard/student" class="block">  
        <div class="absolute inset-x-0 bottom-0 bg-whitebg hover:bg-gray-700 px-4 py-4 sm:px-6">
            <div class="text-sm text-center">
              <p class="font-medium text-white">View all</p>
            </div>
        </div>
      </a>
        
    </div>
  </dl>
</div>



<?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Desktop\libarch\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>
<?php echo $__env->make('partials.adminnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="content px-10">
    <div class="mt-6 mb-4 md:flex md:items-center md:justify-between">
        <div class="inline-flex overflow-hidden border divide-x rounded-lg bg-gray-900 rtl:flex-row-reverse border-gray-700 divide-gray-700">
            <ul class="flex">
                <li class="mr-3">
                    <a class="inline-block rounded py-1.5 px-3  text-white border-b border-b-4 border-white" href="/admin/dashboard/archive">Archive List</a>
                </li>
                <li class="mr-3">
                    <a class="inline-block rounded py-1.5 px-3  text-white " href="/admin/dashboard/archive/pending">Pending List</a>
                </li>
                <li class="">
                    <a class="inline-block rounded py-1.5 px-3  text-white " href="/admin/dashboard/archive/decline">Decline List</a>
                </li>
            </ul>
        </div>
        <div class="text-white w-full h-12 sm:w-2/6 ">
            <form action="<?php echo e(url('/admin/dashboard/archive')); ?>" id="searchForm" method="get" class=" w-full mx-auto h-full">
                <div class="flex flex-row mt-2 sm:mt-0 md:flex-row items-center h-full">
                    <div class="relative h-full">
                        <select id="dropdown" class="text-white w-full md:w-36 bg-whitebg hover:bg-gray-800 font-medium text-sm px-2 py-4 md:py-0 h-full rounded-lg-g md:rounded-l-lg" name="student_department">
                            <option value="" <?php echo e(request()->input('student_department') ? '' : 'selected'); ?>>Department</option>
                            <option value="Marketing & Entrepreneurship" <?php echo e(request()->input('student_department') === 'Marketing & Entrepreneurship' ? 'selected' : ''); ?>>Marketing & Entrepreneurship</option>
                            <option value="Engineering" <?php echo e(request()->input('student_department') === 'Engineering' ? 'selected' : ''); ?>>Engineering</option>
                            <option value="Information Technology" <?php echo e(request()->input('student_department') === 'Information Technology' ? 'selected' : ''); ?>>Information Technology</option>
                            <option value="Tourism" <?php echo e(request()->input('student_department') === 'Tourism' ? 'selected' : ''); ?>>Tourism</option>
                            <option value="Education" <?php echo e(request()->input('student_department') === 'Education' ? 'selected' : ''); ?>>Education</option>
                            <option value="Psychology" <?php echo e(request()->input('student_department') === 'Psychology' ? 'selected' : ''); ?>>Psychology</option>
                        </select>
                    </div>
                    <input type="search" id="default-search" value="<?php echo e(request()->input('search')); ?>" name="search" class="w-full p-4 text-sm text-white bg-transparent hover:bg-gray-800 focus:outline-none md:py-0 h-full md:border-b-2 md:border-t-2 border-y-2 border-whitebg md:border-whitebg " placeholder="Search Title" />
                    <button type="submit" class="text-white bg-whitebg hover:bg-gray-800 font-medium text-sm px-4 py-4 md:py-0 h-full rounded-lg-g md:rounded-r-lg">Search</button>
                </div>
            </form>
        </div>
    </div>
    <hr><br>
    <div class="flex flex-col">
        <div class="-mx-4 -my-2 overflow-x-auto sm:-mx-6 ">
              <div class="inline-block min-w-full py-2 align-middle md:px-6 lg:px-8">
                 <div class="overflow-hidden border border-gray-700 md:rounded-lg">
                    <table class="min-w-full divide-y divide-gray-700">
                        <thead class="bg-gray-800">
                            <tr>
                                <th scope="col" class="py-3.5 px-4 text-sm font-normal text-left rtl:text-right text-gray-400">
                                    <div class="flex items-center gap-x-3">
                                        <button class="flex items-center gap-x-2">
                                            <span>Title</span>
                                        </button>
                                    </div>
                                </th>
                                <th scope="col" class="px-4 py-3.5 text-sm font-normal text-left rtl:text-right text-gray-400">
                                    Year
                                </th>
                                <th scope="col" class="px-4 py-3.5 text-sm font-normal text-left rtl:text-right text-gray-400">
                                    Uploader
                                </th>
                                <th scope="col" class="px-4 py-3.5 text-sm font-normal text-left rtl:text-right text-gray-400">
                                    Department
                                </th>
                                <th scope="col" class="px-4 py-3.5 text-sm font-normal text-left rtl:text-right text-gray-400">
                                    Action
                                </th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-700 bg-gray-900">
                            <?php $__empty_1 = true; $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <?php if($item->status == 1): ?>
                                    <tr>
                                        <td class="px-4 py-4 text-sm font-medium text-gray-300 whitespace-nowrap">
                                            <div class="inline-flex items-center gap-x-3">
                                                <span><?php echo e($item->title); ?></span>
                                            </div>
                                        </td>
                                        <td class="px-4 py-4 text-sm text-gray-300 whitespace-nowrap">
                                            <?php echo e($item->year); ?>

                                        </td>
                                        <td class="px-4 py-4 text-sm text-gray-300 whitespace-nowrap">
                                            <h2 class="text-sm font-normal"><?php echo e($item->student_firstname); ?> <?php echo e($item->student_lastname); ?></h2>
                                        </td>
                                        <td class="px-4 py-4 text-sm text-gray-300 whitespace-nowrap">
                                            <?php if($item->student_department == "Marketing & Entrepreneurship"): ?>
                                                <h1 class="text-white">Marketing & Entrepreneurship</h1>
                                            <?php elseif($item->student_department == "Engineering"): ?>
                                                <p class="text-white">Engineering</p>
                                            <?php elseif($item->student_department == "Information Technology"): ?>
                                                <p class="text-white">Information Technology</p>
                                            <?php elseif($item->student_department == "Tourism"): ?>
                                                <p class="text-white">Tourism</p>
                                            <?php elseif($item->student_department == "Education"): ?>
                                                <p class="text-white">Education</p>
                                            <?php elseif($item->student_department == "Psychology"): ?>
                                                <p class="text-white">Psychology</p>
                                            <?php endif; ?>
                                        </td>
                                        <td class="px-1 py-4 text-sm whitespace-nowrap">
                                            <a href="/admin/dashboard/archive/view/<?php echo e($item->id); ?>">
                                                <button class="hover:border-indigo-500 text-white hover:text-whitebg font-bold py-2 px-4 rounded-full">View</button>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="5" class="px-4 py-4 text-sm font-medium text-gray-200 whitespace-nowrap text-center">
                                        No data available.
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>                    
                 </div>
                 <nav aria-label="Page navigation example" class="mt-4 grid justify-items-center">
                    <?php if($files->hasPages()): ?>
                        <div class="flex">
                            <!-- Previous Button -->
                            <?php if($files->onFirstPage()): ?>
                                <span class="flex items-center justify-center mr-3 px-3 h-8 text-sm font-medium border rounded-lg bg-gray-800 border-gray-700 text-gray-400">Previous</span>
                            <?php else: ?>
                                <a href="<?php echo e($files->previousPageUrl()); ?>" class="flex mr-3 items-center justify-center px-3 h-8 text-sm font-medium border rounded-lg bg-gray-800 border-gray-700 text-gray-400 hover:bg-gray-700 hover:text-white">Previous</a>
                            <?php endif; ?>
                
                            <ul class="flex items-center -space-x-px h-8 text-sm">
                                <?php $__currentLoopData = $files->links()->elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(is_string($element)): ?>
                                        <li>
                                            <span class="flex items-center justify-center px-3 h-8 leading-tight border bg-gray-800 border-gray-700 text-gray-400"><?php echo e($element); ?></span>
                                        </li>
                                    <?php endif; ?>
                                    <?php if(is_array($element)): ?>
                                        <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($page == $files->currentPage()): ?>
                                                <li>
                                                    <span class="flex items-center justify-center px-3 h-8 leading-tight border bg-gray-800 border-gray-700 text-gray-400"><?php echo e($page); ?></span>
                                                </li>
                                            <?php else: ?>
                                                <li>
                                                    <a href="<?php echo e($url); ?>" class="flex items-center justify-center px-3 h-8 leading-tight border bg-gray-800 border-gray-700 text-gray-400 hover:bg-gray-700 hover:text-white"><?php echo e($page); ?></a>
                                                </li>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                
                            <!-- Next Button -->
                            <?php if($files->hasMorePages()): ?>
                                <a href="<?php echo e($files->nextPageUrl()); ?>" class="flex items-center justify-center px-3 h-8 ml-3 text-sm font-medium border rounded-lg bg-gray-800 border-gray-700 text-gray-400 hover:bg-gray-700 hover:text-white">Next</a>
                            <?php else: ?>
                                <span class="flex items-center justify-center px-3 h-8 ml-3 text-sm font-medium border rounded-lg bg-gray-800 border-gray-700 text-gray-400">Next</span>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </nav> 
             </div>
         </div>
     </div>
     <script>
        document.getElementById('dropdownButton').addEventListener('click', function() {
            document.getElementById('dropdown').classList.toggle('hidden');
        });
    </script>
<?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Admin\Desktop\libarch\resources\views/archive/list.blade.php ENDPATH**/ ?>
<?php echo $__env->make('partials.studentnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div id="history-content" class=" max-h-[200px] overflow-y-auto mt-2 p-2 bg-whitebg text-white">
    <?php $__empty_1 = true; $__currentLoopData = $history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <p><?php echo e($record->student->firstname); ?></p>
        <p><?php echo e($record->document->title); ?></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p>No history available.</p>
    <?php endif; ?>
</div>
<?php /**PATH C:\Users\Admin\Desktop\libarch\resources\views/archive/history.blade.php ENDPATH**/ ?>